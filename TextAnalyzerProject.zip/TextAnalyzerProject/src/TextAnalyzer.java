import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class TextAnalyzer {
	
	public static void main(String[] args) {
		Path poemFile = Paths.get("C:\\Users\\colla\\Desktop\\TextAnalyzer\\Poem.html");
		
		try {
			String fileText = Files.readString(poemFile);
			fileText = fileText.toLowerCase();
			
			Pattern allowedCharacters = Pattern.compile("[a-z]+");
			Matcher characterMatcher = allowedCharacters.matcher(fileText);
            
			TreeMap<String, Integer> wordCounter = new TreeMap<>();
            
			while (characterMatcher.find()) {
				String word = characterMatcher.group();
				
				if (wordCounter.containsKey(word)) {
					wordCounter.computeIfPresent(word, (w, c) -> Integer.valueOf(c.intValue() + 1));
					}
				else {
                	wordCounter.computeIfAbsent(word, (w) -> Integer.valueOf(1));
                	}
				}
			
			Set<Map.Entry<String, Integer>> fileSet = wordCounter.entrySet();
            List<Map.Entry<String, Integer>> fileList = new ArrayList<Map.Entry<String, Integer>>(fileSet);
            
            Collections.sort( fileList, new Comparator<Map.Entry<String, Integer>>() {
            	public int compare(Map.Entry<String, Integer> a, Map.Entry<String, Integer> b)
            	{
            		return (b.getValue()).compareTo(a.getValue());
            		}
            	});
            
            for(Map.Entry<String, Integer> i:fileList) {
            	System.out.println(i.getKey()+" -> "+i.getValue());
            	}
            }
		catch (IOException xIo) {
			xIo.printStackTrace();
			}
		}
	}