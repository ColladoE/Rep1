public interface LoanConstants {
	int shortTerm = 1;
	int mediumTerm = 3;
	int longTerm = 5;
	String companyName = "JPL";
	double maximumLoanAmount = 50000;
}