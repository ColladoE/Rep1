public abstract class Loans implements LoanConstants {
	int loanNumber;
    String customerLastName;
    double loanAmount;
    double interestRate;
    int termLength;
    
    public Loans (int loanNumber, String customerLastName, double loanAmount, int termLength) {
                super();
                this.loanNumber = loanNumber;
                this.customerLastName = customerLastName;
                if
                	(loanAmount<=LoanConstants.maximumLoanAmount){
                	this.loanAmount = loanAmount;
                }
                if
                	(loanAmount>LoanConstants.maximumLoanAmount){
                     System.out.println("Loan amount cannot exceed "+LoanConstants.maximumLoanAmount);
                     System.exit(0);
                }
                if
                	(termLength!=LoanConstants.shortTerm && termLength!=LoanConstants.mediumTerm && termLength!=LoanConstants.longTerm)
                	this.termLength = LoanConstants.shortTerm;
                else
                    this.termLength = termLength;
        }
    
    public String toString() {
                return "Loan Number= " + loanNumber + "\nLast Name= " + customerLastName + "\nPrincipal Amount= " + loanAmount + "\nInterest Rate= " + interestRate + "\nTerm Length(in years)= "+ termLength ;
        }
    
    public boolean equals(Loans l) {
                if(this.loanAmount==l.loanAmount && this.interestRate==l.interestRate && this.termLength==l.termLength)
                	return true;
                else
                	return false;
        }
}