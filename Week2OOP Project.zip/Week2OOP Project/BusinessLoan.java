public class BusinessLoan extends Loans{

	public BusinessLoan(int loanNumber, String customerLastName, double loanAmount, int termLength,
			double interestRate) {
                super(loanNumber, customerLastName, loanAmount, termLength);
                this.interestRate = interestRate + .01;
        }
}