public class PersonalLoan extends Loans{
	
	public PersonalLoan(int loanNumber, String customerLastName, double loanAmount, int termLength, double interestRate) {
            super(loanNumber, customerLastName, loanAmount, termLength);
            this.interestRate = (interestRate + .02);
    }
}