import java.util.Scanner;

public class CreateLoans {

        public static void main(String[] args) {
                Scanner loanInput = new Scanner(System.in);
                Loans l[] = new Loans[5];
                double grandTotalLoan = 0;
                double businessLoanTotal = 0;
                double personalLoanTotal = 0;
                System.out.print("Enter the current prime interest rate: ");
                double interestRate = loanInput.nextDouble();
                for(int i=0;i<5;i++){
                        System.out.print("\nPress 1.Business Loan 2.Personal Loan\nEnter your choice: ");
                        int loanType = loanInput.nextInt();
                        loanInput.nextLine();
                        int loanNumber = 1 + i ;
                        System.out.print("\nEnter last name: ");
                        String customerLastName = loanInput.nextLine();
                        System.out.print("\nEnter loan amount: ");
                        double loanAmount = loanInput.nextDouble();
                        System.out.print("\nEnter loan term length (in years): ");
                        int termLength = loanInput.nextInt();
                        loanInput.nextLine();
                        if(loanType==1){
                                double businessLoanRate = interestRate * 1.01;
                                l[i] = new BusinessLoan(loanNumber, customerLastName, loanAmount, termLength, interestRate);
                                double sum = l[i].loanAmount*l[i].interestRate*l[i].termLength/100 + l[i].loanAmount;
                                businessLoanTotal += sum;
                        }
                        if(loanType==2){
                                double personalLoanRate = interestRate * 1.02;
                                l[i] = new PersonalLoan(loanNumber, customerLastName, loanAmount, termLength, interestRate);
                                double sum = l[i].loanAmount*l[i].interestRate*l[i].termLength/100 + l[i].loanAmount;
                                personalLoanTotal += sum;
                        }
                }
                for(int i=0;i<5;i++){
                        System.out.println(l[i].toString());
                        double sum = l[i].loanAmount*l[i].interestRate*l[i].termLength/100 + l[i].loanAmount;
                        grandTotalLoan += sum;
                        System.out.println("Total amount owed at due date: "+sum);
                }
                System.out.println("\nTotal Business Loan amount JPL has loaned out: "+businessLoanTotal);
                System.out.println("\nTotal Personal Loan amount JPL has loaned out:"+personalLoanTotal);
                System.out.println("\n\nGrand Total Loan amount JPL has loaned out: "+grandTotalLoan);
        }

}